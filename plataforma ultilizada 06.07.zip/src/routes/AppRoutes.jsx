import { Routes, Route, Navigate } from 'react-router-dom'

import Login from '../pages/Login'
import RedefinirSenha from '../pages/RedefinirSenha'
import Dashboard from '../pages/Dashboard'
import OperacaoDoDia from '../pages/OperacaoDoDia'
import Motoristas from '../pages/Motoristas'
import Historico from '../pages/Historico'
import LeadTime from '../pages/LeadTime'
import Pendencias from '../pages/Pendencias'
import Relatorios from '../pages/Relatorios'
import Importacoes from '../pages/Importacoes'
import FunilOperacional from '../pages/FunilOperacional'
import GargalosOperacionais from '../pages/GargalosOperacionais'
import PrazoRotas from '../pages/PrazoRotas'
import ComunicadosOperacionais from '../pages/ComunicadosOperacionais'
import AlertasOperacionais from '../pages/AlertasOperacionais'
import AlteracoesOperacionais from '../pages/AlteracoesOperacionais'
import AssistenteIA from '../pages/AssistenteIA'
import EvolucaoMotoristas from '../pages/EvolucaoMotoristas'
import EvolucaoMensal from '../pages/EvolucaoMensal'
import Configuracoes from '../pages/Configuracoes'
import Auditoria from '../pages/Auditoria'
import GestaoUsuarios from '../pages/GestaoUsuarios'
import Lixeira from '../pages/Lixeira'
import NotFound from '../pages/NotFound'

import AppLayout from '../components/layout/AppLayout'
import RequireAuth from '../components/layout/RequireAuth'
import RequireProfile from '../components/layout/RequireProfile'

export default function AppRoutes() {
  return (
    <Routes>
      {/* Rotas públicas */}
      <Route path="/login" element={<Login />} />
      <Route path="/redefinir-senha" element={<RedefinirSenha />} />

      {/* Rotas protegidas — exigem sessão Supabase válida + usuário ativo */}
      <Route
        element={
          <RequireAuth>
            <AppLayout />
          </RequireAuth>
        }
      >
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/operacao" element={<OperacaoDoDia />} />
        <Route path="/motoristas" element={<Motoristas />} />
        <Route path="/historico" element={<Historico />} />
        <Route path="/leadtime" element={<LeadTime />} />
        <Route path="/pendencias" element={<Pendencias />} />
        <Route path="/relatorios" element={<Relatorios />} />
        <Route path="/importacoes"  element={<Importacoes />} />
        <Route path="/funil"        element={<FunilOperacional />} />
        <Route path="/gargalos"     element={<GargalosOperacionais />} />
        <Route path="/prazo-rotas"  element={<PrazoRotas />} />
        <Route path="/comunicados"  element={<ComunicadosOperacionais />} />
        <Route path="/alertas"      element={<AlertasOperacionais />} />
        <Route path="/alteracoes"   element={<AlteracoesOperacionais />} />
        <Route path="/assistente"          element={<AssistenteIA />} />
        <Route path="/evolucao-motoristas" element={<EvolucaoMotoristas />} />
        <Route path="/evolucao-mensal"     element={<EvolucaoMensal />} />
        <Route path="/lixeira"             element={<Lixeira />} />

        {/* Exclusiva de administrador */}
        <Route
          path="/configuracoes"
          element={
            <RequireProfile>
              <Configuracoes />
            </RequireProfile>
          }
        />
        <Route
          path="/configuracoes/auditoria"
          element={
            <RequireProfile>
              <Auditoria />
            </RequireProfile>
          }
        />
        <Route
          path="/configuracoes/usuarios"
          element={
            <RequireProfile>
              <GestaoUsuarios />
            </RequireProfile>
          }
        />
      </Route>

      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
