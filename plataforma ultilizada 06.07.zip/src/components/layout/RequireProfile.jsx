import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../../contexts/AuthContext'
import { podeAcessar } from '../../lib/permissions'

/**
 * Restringe o acesso a uma rota com base no perfil do usuário (ex.:
 * Configurações é exclusiva de administrador). Deve ser usado dentro de
 * <RequireAuth>, que já garante usuário ativo e carregado.
 */
export default function RequireProfile({ children }) {
  const { perfil } = useAuth()
  const location = useLocation()

  if (!podeAcessar(location.pathname, perfil)) {
    return <Navigate to="/dashboard" replace />
  }

  return children
}
